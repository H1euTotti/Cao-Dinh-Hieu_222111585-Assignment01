﻿namespace Cao_Dinh_Hieu_22111585_Assigment01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_onred = new System.Windows.Forms.Button();
            this.bnt_ongreen = new System.Windows.Forms.Button();
            this.bnt_onyellow = new System.Windows.Forms.Button();
            this.bnt_offred = new System.Windows.Forms.Button();
            this.bnt_offgreeen = new System.Windows.Forms.Button();
            this.bnt_yellowoff = new System.Windows.Forms.Button();
            this.pnl_red = new System.Windows.Forms.Panel();
            this.pnl_yellow = new System.Windows.Forms.Panel();
            this.pnl_green = new System.Windows.Forms.Panel();
            this.btn_start = new System.Windows.Forms.Button();
            this.btn_finish = new System.Windows.Forms.Button();
            this.btn_setting = new System.Windows.Forms.Button();
            this.dtp_time = new System.Windows.Forms.DateTimePicker();
            this.btn_help = new System.Windows.Forms.Button();
            this.txt_time = new System.Windows.Forms.TextBox();
            this.btn_texttime = new System.Windows.Forms.Button();
            this.btn_reset = new System.Windows.Forms.Button();
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.pnl_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_onred
            // 
            this.btn_onred.ForeColor = System.Drawing.Color.Fuchsia;
            this.btn_onred.Location = new System.Drawing.Point(334, 46);
            this.btn_onred.Name = "btn_onred";
            this.btn_onred.Size = new System.Drawing.Size(75, 23);
            this.btn_onred.TabIndex = 7;
            this.btn_onred.Text = "ON";
            this.btn_onred.UseVisualStyleBackColor = true;
            // 
            // bnt_ongreen
            // 
            this.bnt_ongreen.ForeColor = System.Drawing.Color.Fuchsia;
            this.bnt_ongreen.Location = new System.Drawing.Point(334, 337);
            this.bnt_ongreen.Name = "bnt_ongreen";
            this.bnt_ongreen.Size = new System.Drawing.Size(75, 23);
            this.bnt_ongreen.TabIndex = 8;
            this.bnt_ongreen.Text = "ON";
            this.bnt_ongreen.UseVisualStyleBackColor = true;
            // 
            // bnt_onyellow
            // 
            this.bnt_onyellow.ForeColor = System.Drawing.Color.Fuchsia;
            this.bnt_onyellow.Location = new System.Drawing.Point(334, 193);
            this.bnt_onyellow.Name = "bnt_onyellow";
            this.bnt_onyellow.Size = new System.Drawing.Size(75, 23);
            this.bnt_onyellow.TabIndex = 9;
            this.bnt_onyellow.Text = "ON";
            this.bnt_onyellow.UseVisualStyleBackColor = true;
            // 
            // bnt_offred
            // 
            this.bnt_offred.ForeColor = System.Drawing.Color.Red;
            this.bnt_offred.Location = new System.Drawing.Point(334, 123);
            this.bnt_offred.Name = "bnt_offred";
            this.bnt_offred.Size = new System.Drawing.Size(75, 23);
            this.bnt_offred.TabIndex = 10;
            this.bnt_offred.Text = "OFF";
            this.bnt_offred.UseVisualStyleBackColor = true;
            this.bnt_offred.Click += new System.EventHandler(this.button4_Click);
            // 
            // bnt_offgreeen
            // 
            this.bnt_offgreeen.ForeColor = System.Drawing.Color.Red;
            this.bnt_offgreeen.Location = new System.Drawing.Point(334, 414);
            this.bnt_offgreeen.Name = "bnt_offgreeen";
            this.bnt_offgreeen.Size = new System.Drawing.Size(75, 23);
            this.bnt_offgreeen.TabIndex = 11;
            this.bnt_offgreeen.Text = "OFF";
            this.bnt_offgreeen.UseVisualStyleBackColor = true;
            // 
            // bnt_yellowoff
            // 
            this.bnt_yellowoff.ForeColor = System.Drawing.Color.Red;
            this.bnt_yellowoff.Location = new System.Drawing.Point(334, 270);
            this.bnt_yellowoff.Name = "bnt_yellowoff";
            this.bnt_yellowoff.Size = new System.Drawing.Size(75, 23);
            this.bnt_yellowoff.TabIndex = 12;
            this.bnt_yellowoff.Text = "OFF";
            this.bnt_yellowoff.UseVisualStyleBackColor = true;
            // 
            // pnl_red
            // 
            this.pnl_red.BackColor = System.Drawing.Color.Red;
            this.pnl_red.Cursor = System.Windows.Forms.Cursors.Cross;
            this.pnl_red.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.pnl_red.Location = new System.Drawing.Point(69, 337);
            this.pnl_red.Name = "pnl_red";
            this.pnl_red.Size = new System.Drawing.Size(200, 100);
            this.pnl_red.TabIndex = 13;
            // 
            // pnl_yellow
            // 
            this.pnl_yellow.BackColor = System.Drawing.Color.Yellow;
            this.pnl_yellow.Location = new System.Drawing.Point(69, 193);
            this.pnl_yellow.Name = "pnl_yellow";
            this.pnl_yellow.Size = new System.Drawing.Size(200, 100);
            this.pnl_yellow.TabIndex = 14;
            // 
            // pnl_green
            // 
            this.pnl_green.BackColor = System.Drawing.Color.Lime;
            this.pnl_green.Location = new System.Drawing.Point(69, 46);
            this.pnl_green.Name = "pnl_green";
            this.pnl_green.Size = new System.Drawing.Size(200, 100);
            this.pnl_green.TabIndex = 15;
            // 
            // btn_start
            // 
            this.btn_start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn_start.ForeColor = System.Drawing.Color.Blue;
            this.btn_start.Location = new System.Drawing.Point(790, 88);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(151, 82);
            this.btn_start.TabIndex = 16;
            this.btn_start.Text = "START";
            this.btn_start.UseVisualStyleBackColor = false;
            // 
            // btn_finish
            // 
            this.btn_finish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn_finish.ForeColor = System.Drawing.Color.Blue;
            this.btn_finish.Location = new System.Drawing.Point(790, 248);
            this.btn_finish.Name = "btn_finish";
            this.btn_finish.Size = new System.Drawing.Size(151, 82);
            this.btn_finish.TabIndex = 17;
            this.btn_finish.Text = "FINISH";
            this.btn_finish.UseVisualStyleBackColor = false;
            // 
            // btn_setting
            // 
            this.btn_setting.BackColor = System.Drawing.Color.Gray;
            this.btn_setting.ForeColor = System.Drawing.Color.Aqua;
            this.btn_setting.Location = new System.Drawing.Point(957, 12);
            this.btn_setting.Name = "btn_setting";
            this.btn_setting.Size = new System.Drawing.Size(83, 20);
            this.btn_setting.TabIndex = 18;
            this.btn_setting.Text = "SETTINGS";
            this.btn_setting.UseVisualStyleBackColor = false;
            this.btn_setting.Click += new System.EventHandler(this.btn_setting_Click);
            // 
            // dtp_time
            // 
            this.dtp_time.CalendarTitleForeColor = System.Drawing.Color.Red;
            this.dtp_time.Location = new System.Drawing.Point(1165, 12);
            this.dtp_time.Name = "dtp_time";
            this.dtp_time.Size = new System.Drawing.Size(285, 20);
            this.dtp_time.TabIndex = 19;
            // 
            // btn_help
            // 
            this.btn_help.BackColor = System.Drawing.Color.Gray;
            this.btn_help.ForeColor = System.Drawing.Color.Aqua;
            this.btn_help.Location = new System.Drawing.Point(1058, 12);
            this.btn_help.Name = "btn_help";
            this.btn_help.Size = new System.Drawing.Size(91, 20);
            this.btn_help.TabIndex = 20;
            this.btn_help.Text = "HELP";
            this.btn_help.UseVisualStyleBackColor = false;
            // 
            // txt_time
            // 
            this.txt_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_time.Location = new System.Drawing.Point(1058, 271);
            this.txt_time.Multiline = true;
            this.txt_time.Name = "txt_time";
            this.txt_time.Size = new System.Drawing.Size(151, 58);
            this.txt_time.TabIndex = 21;
            this.txt_time.Text = "00:00";
            // 
            // btn_texttime
            // 
            this.btn_texttime.BackColor = System.Drawing.Color.Silver;
            this.btn_texttime.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_texttime.Location = new System.Drawing.Point(1058, 248);
            this.btn_texttime.Name = "btn_texttime";
            this.btn_texttime.Size = new System.Drawing.Size(151, 26);
            this.btn_texttime.TabIndex = 22;
            this.btn_texttime.Text = "TIME:";
            this.btn_texttime.UseVisualStyleBackColor = false;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.SystemColors.ControlText;
            this.btn_reset.ForeColor = System.Drawing.Color.Aqua;
            this.btn_reset.Location = new System.Drawing.Point(1058, 88);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(151, 82);
            this.btn_reset.TabIndex = 23;
            this.btn_reset.Text = "RESET";
            this.btn_reset.UseVisualStyleBackColor = false;
            // 
            // pnl_menu
            // 
            this.pnl_menu.BackColor = System.Drawing.Color.Black;
            this.pnl_menu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pnl_menu.Controls.Add(this.pnl_green);
            this.pnl_menu.Controls.Add(this.pnl_yellow);
            this.pnl_menu.Controls.Add(this.pnl_red);
            this.pnl_menu.Controls.Add(this.btn_onred);
            this.pnl_menu.Controls.Add(this.bnt_offred);
            this.pnl_menu.Controls.Add(this.bnt_onyellow);
            this.pnl_menu.Controls.Add(this.bnt_yellowoff);
            this.pnl_menu.Controls.Add(this.bnt_ongreen);
            this.pnl_menu.Controls.Add(this.bnt_offgreeen);
            this.pnl_menu.Location = new System.Drawing.Point(22, 24);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(440, 477);
            this.pnl_menu.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1462, 623);
            this.Controls.Add(this.pnl_menu);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_texttime);
            this.Controls.Add(this.txt_time);
            this.Controls.Add(this.btn_help);
            this.Controls.Add(this.dtp_time);
            this.Controls.Add(this.btn_setting);
            this.Controls.Add(this.btn_finish);
            this.Controls.Add(this.btn_start);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnl_menu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_onred;
        private System.Windows.Forms.Button bnt_ongreen;
        private System.Windows.Forms.Button bnt_onyellow;
        private System.Windows.Forms.Button bnt_offred;
        private System.Windows.Forms.Button bnt_offgreeen;
        private System.Windows.Forms.Button bnt_yellowoff;
        private System.Windows.Forms.Panel pnl_red;
        private System.Windows.Forms.Panel pnl_yellow;
        private System.Windows.Forms.Panel pnl_green;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Button btn_finish;
        private System.Windows.Forms.Button btn_setting;
        private System.Windows.Forms.DateTimePicker dtp_time;
        private System.Windows.Forms.Button btn_help;
        private System.Windows.Forms.TextBox txt_time;
        private System.Windows.Forms.Button btn_texttime;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Panel pnl_menu;
    }
}

